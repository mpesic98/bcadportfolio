import adA from "../../assets/300x250.jpg"
import adB from "../../assets/displaybanner.png"
import adC from "../../assets/300x250.jpg"
import adD from "../../assets/300x600.jpg"
import adE from "../../assets/slider.png"
import adF from "../../assets/1070x27.png"
import railL from "../../assets/sideskin.png"
import railR from "../../assets/sideskin.png"

export default function DisplayCreative({ slotId, size = "300x250" }) {
  const map = {
    rail_left_160x600: railL,
    rail_right_160x600: railR,
    top_1070x27: adF,
    sidebar_300x250_1: adA,
    sidebar_300x250_2: adC,
    inline_300x600: adD,
    inline_300x250_1: adE,
    inline_300x250_3: adE,
    mobile_inline_300x600: adD,
    mobile_inline_300x250_1: adA,
    mobile_inline_300x250_2: adC,
    mobile_inline_300x250_3: adE,
    mobile_sticky_320x50: adB,
  }

  const [w, h] = size.split("x").map(Number)
  const src = map[slotId] || adA

  return (
    <div className="w-full flex justify-center">
      <div
        className="relative overflow-hidden rounded bg-white border border-neutral-300 shadow-sm"
        style={{ width: w, height: h }}
      >
        <img src={src} alt={slotId} className="w-full h-full object-cover" />
        <div className="absolute top-2 left-2 text-[10px] px-2 py-1 rounded bg-neutral-900 text-white">
          {slotId} - {w}x{h}
        </div>
      </div>
    </div>
  )
}
